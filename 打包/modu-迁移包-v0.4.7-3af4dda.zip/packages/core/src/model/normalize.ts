/**
 * design json 读取侧自动迁移（v1 → v2 → … → v5）。
 *
 * v2 变更：calledExternalFunctions 收窄为只放普通外部接口（5.2.2.2），
 * Callout 函数（group === 'Callout'）移入新顶层节点 calloutFunctions（6.2）。
 * 存量 v1 json 两类混放在 calledExternalFunctions 里，本函数在读取侧就地拆分，
 * 使旧 json 无需重跑 analyze 即可被 report/diff/lint 等新代码消费。
 *
 * v5 变更：document.configDetails 单一对象拆为 configDetailsGeneral/configDetailsFunctional
 * 两个对象（按对应宏的 kind 归属；别名宏本就不在 configDetails 内）。
 *
 * 另：chapter 值精确化（同 schema 内值演进，不升版本）——5.1 功能描述下拆
 * 5.1.1 功能接口总图 / 5.1.2 内部函数调用图（与 Polarion 样板对齐），
 * 存量 json 的 interfaceOverview/callGraphs polarion.chapter=5.1 就地改写。
 *
 * 契约：**就地迁移**，原地修改入参并返回同一引用（同 materializePolarionAttributes 先例）；
 * **形态驱动、幂等**——不看 schemaVersion 决定动不动，只看数据形态，重复调用结果不变。
 * 磁盘写回不在这里做：迁移后的形态随 gen/images 的 save 自然落盘。
 */
import { SCHEMA_VERSION, type ConfigDetailEntry, type ConfigMacro, type ModuleModel, type StateMachineDesign } from './types.js';

export function normalizeModel(model: ModuleModel): ModuleModel {
  model.calloutFunctions ??= [];
  const cef = model.calledExternalFunctions ?? [];
  const stray = cef.filter(e => e.group === 'Callout');
  if (stray.length > 0) {
    const known = new Set(model.calloutFunctions.map(e => e.name));
    for (const e of stray) {
      if (!known.has(e.name)) { model.calloutFunctions.push(e); known.add(e.name); }
    }
    model.calledExternalFunctions = cef.filter(e => e.group !== 'Callout');
  }
  // stateMachine 旧字段迁移：单核产物只有 stateMachine 无 stateMachines，就地升为数组
  const dd = model.dynamicDesign as { stateMachine?: StateMachineDesign | null; stateMachines?: StateMachineDesign[] } | undefined;
  if (dd && !dd.stateMachines && dd.stateMachine) {
    dd.stateMachines = [dd.stateMachine];
    delete dd.stateMachine;
  }
  // configMacros 旧字段迁移：v4 起按 kind 拆三桶（general/functional/alias），就地拆分；
  // 桶内保持旧数组相对序，并给每条打 _seq（旧数组原始索引）——渲染期跨桶名单（7 章评估等）
  // 按 _seq 还原 v4 前 configMacros 全序，保证存量 json 现算产物字节零回归；新产物无 _seq 落桶序。
  // 合并而非覆盖：存量桶内已有条目按名保留（防御手工编辑/部分迁移的 json 两侧并存致数据丢失）
  const legacy = model as unknown as { configMacros?: ConfigMacro[] };
  if (legacy.configMacros) {
    if (!model.generalConfigMacros && !model.functionalConfigMacros && !model.aliasConfigMacros) {
      legacy.configMacros.forEach((c, i) => { (c as ConfigMacro & { _seq?: number })._seq = i; });
    }
    const mergeBucket = (bucket: ConfigMacro[] | undefined, kind: ConfigMacro['kind']): ConfigMacro[] => {
      const fromLegacy = legacy.configMacros!.filter(c => c.kind === kind);
      const kept = bucket ?? [];
      const names = new Set(kept.map(c => c.name));
      return [...kept, ...fromLegacy.filter(c => !names.has(c.name))];
    };
    model.generalConfigMacros = mergeBucket(model.generalConfigMacros, 'general');
    model.functionalConfigMacros = mergeBucket(model.functionalConfigMacros, 'functional');
    model.aliasConfigMacros = mergeBucket(model.aliasConfigMacros, 'alias');
    delete legacy.configMacros;
  }
  model.generalConfigMacros ??= [];
  model.functionalConfigMacros ??= [];
  model.aliasConfigMacros ??= [];
  // configDetails 旧字段迁移：v5 起拆 configDetailsGeneral/configDetailsFunctional 两个对象，
  // 按对应宏的 kind 归属（与顶层三桶口径一致；别名宏本就不在 configDetails 内），就地拆分。
  const doc = model.document as (ModuleModel['document'] & { configDetails?: Record<string, ConfigDetailEntry> }) | undefined;
  if (doc?.configDetails && doc.configDetailsGeneral === undefined) {
    const generalNames = new Set(model.generalConfigMacros.map(c => c.name));
    doc.configDetailsGeneral = {};
    doc.configDetailsFunctional = {};
    for (const [name, detail] of Object.entries(doc.configDetails)) {
      (generalNames.has(name) ? doc.configDetailsGeneral : doc.configDetailsFunctional)[name] = detail;
    }
    delete doc.configDetails;
  }
  // chapter 值精确化（5.1 功能描述下拆 5.1.1 功能接口总图 / 5.1.2 内部函数调用图，与 Polarion 样板对齐）：
  // 存量 json 的 interfaceOverview/callGraphs polarion.chapter 仍标 5.1，就地按 workItemKind/title 改写。
  // 形态驱动（只认 5.1 + diagram 标记）、幂等（已 5.1.1/5.1.2 或 NULL 安全跳过），不改字节门禁（report 渲染读的是 badge 文字，
  // badge 用 chapter 值直出——见 htmlReport，故属 sync/工作项定位键演进而非报告内容变化）。
  if (model.interfaceOverview?.polarion?.chapter === '5.1') {
    model.interfaceOverview.polarion.chapter = '5.1.1';
  }
  for (const g of model.callGraphs ?? []) {
    if (g.polarion?.chapter === '5.1') g.polarion.chapter = '5.1.2';
  }
  if ((model.schemaVersion ?? 0) < SCHEMA_VERSION) model.schemaVersion = SCHEMA_VERSION;
  return model;
}
