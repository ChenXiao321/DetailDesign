# LLD Agent 操作指南

详细设计生成 agent：C 代码 → ASPICE SWE.3 详细设计 → Polarion。

## 环境准备

1. Node.js ≥ 18（开发环境用的 v25）
2. 安装依赖并构建：
   ```bash
   npm install
   npm run build
   ```

## 使用流程

约定：模块源码放 `测试模块/<模块名>/`，产物统一输出到 `测试产出/<模块名>/`（用 `--out` 指定；
不带 `--out` 时产物写在模块目录内）。下文以试点模块 Gp_EcuStpStdn 为例。

### 第 1 步：静态分析（离线，不依赖 LLM）

```bash
node packages/cli/dist/index.js analyze 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn
```

产出 `测试产出/Gp_EcuStpStdn/lld_model.json`：函数/变量/类型/调用关系/哈希锚点/工作项标识。

### 第 2 步：LLM 生成设计内容

**方式 A：本地 Qwen（内网环境，正式路径）**

LLM 连接配置三选一（优先级：环境变量 > lld.config.json）：

```powershell
# 方式 1：环境变量
$env:LLD_LLM_BASE_URL = "http://10.0.75.130:4000"   # 只给 host:port 会自动补 /v1
$env:LLD_LLM_API_KEY = "local"        # 本地部署通常任意值
$env:LLD_LLM_MODEL = "qwen3.8-27b" # 默认值，可不设

# 方式 2：当前目录放 lld.config.json（参照 lld.config.example.json；已 gitignore，不会进仓库）
```

**先自检连通性**（到新环境第一件事）：

```bash
node packages/cli/dist/index.js ping
# ✓ /models 可达 + ✓ chat 调用成功 → 可以跑 gen
```

```bash
node packages/cli/dist/index.js gen 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn
```

`gen` 逐条目增量落盘 `lld_design.json`，中途断网/中断不丢进度，加 `--resume` 续跑（跳过已生成条目）。
网络抖动自动重试 2 次（退避 1s/2s）；单次请求超时默认 180s，可用 `LLD_LLM_TIMEOUT_MS` 调整。

**方式 B：mock 预览（调试用，不调用任何模型）**

```bash
node packages/cli/dist/index.js gen 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn --mock
```

**只生成部分条目**（调试单个函数/动态设计）：

```bash
node packages/cli/dist/index.js gen 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn --only Gp_EcuStpShdn_Startup,dynamic
```

产出 `测试产出/Gp_EcuStpStdn/lld_design.json`：在模型基础上增加
- 每个函数的 `generated.detailedDescription`（增强描述）+ `generated.flowchart`（Mermaid 流程图）
- `dynamicDesign`：状态机 + 序列图（Mermaid 源码）

### 第 3 步：HTML 评审报告

```bash
node packages/cli/dist/index.js report 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn
```

产出 `测试产出/Gp_EcuStpStdn/lld_report.html`，浏览器打开即可评审：按模板章节排版，
函数条目为工作项卡片样式（Service name/Syntax/Parameters/Description），
含数据类型表、外部接口表、状态机/序列图/流程图（内嵌 mermaid.js 离线渲染）、配置表。

### 第 4 步：评审

打开 `lld_design.json` 检查：
- `providedFunctions[].generated.detailedDescription` —— 接口函数描述
- `providedFunctions[].generated.flowchart` —— 函数流程图（Mermaid 源码）
- `dynamicDesign.stateMachine.diagram` / `dynamicDesign.sequences[].diagram` —— 状态机/序列图源码

Mermaid 可粘贴到支持 Mermaid 的工具（VS Code Mermaid 插件 / mermaid.live）预览；
HTML 报告已内嵌 mermaid.min.js，直接打开即可离线渲染。

### 第 5 步：Polarion 导入与 ID 回写

两步走：本工具生成 Word round-trip 导入文件（内嵌流程图/调用图/状态机/序列图 PNG），
在 Polarion 界面人工导入后，再用导出 csv 回写工作项 ID 形成闭环。REST 直连仅留骨架。

```bash
# 1. 生成导入文件（离线，需本机有 Edge 与 pandoc；产物在 <out>/polarion/，不触碰既有交付件）
node packages/cli/dist/index.js polarion 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn export

# 2. Polarion 项目 → Work Items → Import → Word，选 polarion_workitems.docx，
#    "Split document at" 设 Heading 2，按终端输出的类型映射表选工作项类型

# 3. 导入后从 Polarion 导出工作项 csv（含 ID + Description 列），回写 ID
node packages/cli/dist/index.js polarion 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn map-ids --ids polarion_export.csv

# 4. 重跑 report / export 刷新展示（卡片头部与 manifest 带 workItemId）
```

匹配规则：描述内锚点 `LLD-KEY: <module::chapter::name>` 精确匹配 > title 精确匹配；
未匹配默认报错退出（不回写半吊子），确认后加 `--partial` 放行。
Polarion 连接参数（baseUrl/projectId/token）仅 `push` 骨架用：环境变量 `LLD_POLARION_*`
或 lld.config.json 的 `polarion` 节（参照 lld.config.example.json）。


## 迁移到目标环境运行（Qwen 实测 runbook）

Qwen 服务器（10.0.75.130:4000）只在特定网段可达，实测需在能访问该地址的机器上跑。

**拷贝清单**（整个仓库目录，或至少以下部分）：

```
packages/            # 产品代码（core + cli）
测试模块/            # 模块源码（gen 需要重新 analyze 或读取 lld_model.json）
lld.config.json      # LLM 连接配置（参照 lld.config.example.json 填写）
package.json / package-lock.json
```

**目标环境步骤**：

```bash
npm install          # 或 npm ci；需要 node ≥ 18
npm run build

# 1. 自检连通性（不通会打印排查方向）
node packages/cli/dist/index.js ping

# 2. 静态分析（离线）
node packages/cli/dist/index.js analyze 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn_qwen

# 3. 先单点试一个函数，确认 Qwen 输出格式兼容（prompt 有 Mermaid 格式校验+重试）
node packages/cli/dist/index.js gen 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn_qwen --only Gp_EcuStpShdn_Startup

# 4. 全量跑（约 55 次 LLM 调用；中断后加 --resume 续跑）
node packages/cli/dist/index.js gen 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn_qwen

# 5. 出报告（离线，可在本机做——把 lld_design.json 拷回即可）
node packages/cli/dist/index.js report 测试模块/Gp_EcuStpStdn --out 测试产出/Gp_EcuStpStdn_qwen
```

产物目录用 `_qwen` 后缀与 samples 基准（`测试产出/Gp_EcuStpStdn/`）区分，方便对照评审。
评审重点：描述质量 vs samples、流程图 Mermaid 语法正确率、格式校验重试次数（stderr 日志）。

## 当前状态

| 阶段 | 状态 |
|------|------|
| 静态分析层 | ✅ 完成（Gp_EcuStpShdn 验证通过） |
| LLM 生成层 | ✅ pipeline 完成；示例内容见 `samples/claude_generated_content.json`（由 Claude 生成，用于评审效果） |
| HTML 评审报告 | ✅ 章节完整（17 张 mermaid 图，全中文 + 「推断，待确认」标记） |
| Polarion 同步层 | ✅ 离线导入文件 + ID 回写完成（export → Word round-trip → map-ids）；REST 直连仅骨架（`push` 报未实现） |

## 目录结构

```
packages/            # 产品代码
├── core/            # 纯逻辑（未来 VS Code 插件直接复用）
│   └── src/
│       ├── parser/       # tree-sitter C 解析 + 嵌入式预处理 + 注释块解析
│       ├── analyzer/     # 模块分析 → 中间模型
│       ├── llm/          # LLM Provider（OpenAI兼容/Mock）+ prompt
│       └── generator/    # 生成编排（描述增强、动态设计、重试校验）
├── cli/             # 命令行入口
samples/             # 示例生成内容（LLM 离线内容源）
模板/                # G-B035-005 软件详细设计规范（Code）.docx
参考文件/            # 既有 AI 生成 LLD 参考（1231-2_convert.docx）
测试模块/            # 测试输入：Gp_EcuStpStdn/ 试点模块源码（只放 .c/.h）
测试产出/            # 测试产出：Gp_EcuStpStdn/ 下 lld_model.json / lld_design.json / lld_report.html
```
