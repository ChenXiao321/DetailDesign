import type {
  ModuleModel, FunctionUnit, DynamicDesign, SequenceDesign, TypeUnit,
} from '../model/types.js';
import { SCHEMA_VERSION } from '../model/types.js';
import { normalizeModel } from '../model/normalize.js';
import type { LLMProvider } from '../llm/provider.js';
import {
  buildFunctionDescriptionPrompt,
  buildConfigValueEffectPrompt,
  buildCalloutDescriptionPrompt, buildTypeDescriptionPrompt,
  buildExternalDescriptionPrompt, buildModuleDescriptionPrompt,
} from '../llm/prompts.js';
import { lintMermaidSource, lintFlowchartStructure } from '../report/mermaidPre.js';
import { buildStaticFlowchart, buildFallbackFlowchart } from './staticFlowchart.js';
import { buildStaticStateMachine, polishSmLabels } from './staticStateMachine.js';
import { buildStaticSequence } from './staticSequence.js';
import { buildDocumentContent, type AbbrTableInput } from './staticDocument.js';
import { stampContentHash } from './contentHash.js';
import { materializePolarionAttributes } from './polarionAttributes.js';

/** 流程图断言网（纯函数，导出供静态生成器自检与测试直喂恶意图）：
 *  词法 lint + 结构 lint + 条件编译虚线框存在性 + 编译期宏禁入菱形；返回中文问题清单（空 = 通过） */
export function flowchartProblems(fn: FunctionUnit, text: string): string[] {
  const problems = [...lintMermaidSource(text), ...lintFlowchartStructure(text)];
  // 条件编译虚线框硬校验（v3 实测 Qwen 会整图漏画使能框，或把 #if 误画成运行时菱形）：
  for (const macro of [...new Set([...fn.conditionalFlags, ...(fn.innerCondFlags ?? [])])]) {
    const fcLines = text.split('\n');
    // ① 框存在性：宏名必须出现在注释节点标签（["..."] 行，排除 style/classDef/class 样式行）。
    //    只出现在菱形 {"..."} 里不算数——那是把编译期条件误画成运行时分支。
    //    注释里也接受两段式前缀缩写（GP_ECUSTPSHDN_SAFETY_ENABLE→SAFETY_ENABLE，基线既有风格）；
    //    缩写须仍含下划线（≥2 段），防 GP_X_ENABLE→ENABLE 这种单段缩写在任意注释里误命中。
    const abbrev = macro.replace(/^GP_[A-Za-z0-9]+_/, '');
    const names = abbrev.includes('_') ? [macro, abbrev] : [macro];
    const inNote = fcLines.some(l => l.includes('["') && !/^\s*(style|classDef|class)\s/.test(l) && names.some(n => l.includes(n)));
    if (!inNote) {
      problems.push(
        `缺少条件编译虚线框：宏 ${macro} 对应的代码段未圈出（应有注释节点写明「注：仅在 ${macro} 生效时参与编译」）`,
      );
    }
    // ② 编译期宏禁入菱形：宏在源码中仅出现于 #if/#elif、无运行时 if/for/while 使用时，
    //    菱形标签出现该宏 = 把编译期条件误画成运行时分支。菱形只表达运行时分支。
    //    运行时豁免依据 bodyTextWithPP（截断 8500，超长函数宏在截断外运行时使用会误报——
    //    误报表现为多一次重试进 failures，人工可辨，可接受）。
    const body = fn.bodyTextWithPP ?? fn.bodyText ?? '';
    const runtimeUse = body.split('\n').some(l => l.includes(macro) && /^\s*(?:if|for|while)\s*\(/.test(l));
    const inDiamond = fcLines.some(l => l.includes(macro) && l.includes('{"'));
    if (inDiamond && !runtimeUse) {
      problems.push(
        `宏 ${macro} 是编译期条件（源码中仅出现在 #if/#elif），不得画成菱形判断分支——菱形只用于源码中运行时 if/循环条件`,
      );
    }
  }
  return problems;
}

/** 带重试的生成（格式校验失败时把错误回喂） */
async function generateWithRetry<T>(
  provider: LLMProvider,
  system: string,
  user: string,
  validate: (output: string) => T,
  maxRetries = 2,
): Promise<T> {
  let lastError = '';
  let currentUser = user;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    if (lastError) {
      currentUser = `${user}\n\n# 上次输出的问题\n${lastError}\n请修正后重新输出，严格遵守格式要求。`;
    }
    const output = await provider.generate(system, currentUser);
    try {
      return validate(output);
    } catch (err) {
      lastError = (err as Error).message;
    }
  }
  throw new Error(`LLM 生成失败（重试 ${maxRetries} 次）: ${lastError}`);
}

/** 术语表注入：外部缩写定义（abbreviationsDoc/JSON 节）按「在该 prompt 中实际出现」过滤后附到 user 末尾，
 *  让生成正文的术语口径与外部定义一致；不出现的条目不注入（防 prompt 膨胀稀释）。
 *  出现判定除整词 \bABBR\b 外，还认标识符分段——Spi_Setup/gpSpiChannel 里的 Spi 段也算 SPI 出现
 *  （嵌入式 C 的缩写多以标识符段形式存在；按段精确比对防 SPIN 误命中 SPI） */
function abbrAppears(abbr: string, text: string): boolean {
  const escA = abbr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  if (new RegExp(`\\b${escA}\\b`, 'i').test(text)) return true;
  const target = abbr.toUpperCase();
  for (const w of text.match(/[A-Za-z_][A-Za-z0-9_]*/g) ?? []) {
    for (const seg of w.split(/_|(?<=[a-z])(?=[A-Z])/)) {
      if (seg.length > 0 && seg.toUpperCase() === target) return true;
    }
  }
  return false;
}

function withGlossary(user: string, abbr?: [string, string][]): string {
  if (!abbr || abbr.length === 0) return user;
  const hits = abbr.filter(([a]) => abbrAppears(a, user));
  if (hits.length === 0) return user;
  const lines = hits.map(([a, d]) => `- ${a} = ${d}`).join('\n');
  return `${user}\n\n# 项目术语表（以下缩写的定义以此外部口径为准；描述中涉及这些缩写时按其含义理解，正文保持缩写原形、不要自行展开或改写定义）\n${lines}`;
}

type TypeGenerated = NonNullable<TypeUnit['generated']>;

/** 类型描述输出校验：优先解析 JSON（comment + defines/elements 字典）；非 JSON 时整段兜底为 comment */
function validateTypeDescription(t: TypeUnit): (output: string) => Omit<TypeGenerated, 'llmModel' | 'generatedAt'> {
  return (output: string) => {
    let text = output.trim();
    const fence = text.match(/```(?:json)?\s*\n([\s\S]*?)```/);
    if (fence) text = fence[1].trim();
    // 模型若在 JSON 前后加解释文字，截取第一个 {...} 块再解析
    let obj: { comment?: unknown; defines?: unknown; elements?: unknown } | null = null;
    try {
      obj = JSON.parse(text);
    } catch {
      const block = text.match(/\{[\s\S]*\}/);
      if (block) {
        try { obj = JSON.parse(block[0]); } catch { obj = null; }
      }
    }
    if (!obj) {
      // 非 JSON 输出兜底：整段作为类型整体描述，成员/常量说明留空（报告回退源码注释）
      if (text.length < 10) throw new Error('描述过短（<10字符）');
      return { comment: text };
    }
    const comment = typeof obj.comment === 'string' ? obj.comment.trim() : '';
    if (comment.length < 10) {
      throw new Error('JSON 中 comment 缺失或过短（<10字符）。要求：输出 JSON 对象，comment 为类型整体用途（1~2 句话）。请重新输出。');
    }
    // 只收键名与静态分析列表完全一致的条目，防编造键污染表格
    const pick = (src: unknown, names: string[] | undefined): Record<string, string> | undefined => {
      if (!names?.length || src == null || typeof src !== 'object') return undefined;
      const out: Record<string, string> = {};
      for (const n of names) {
        const v = (src as Record<string, unknown>)[n];
        if (typeof v === 'string' && v.trim()) out[n] = v.trim();
      }
      return Object.keys(out).length > 0 ? out : undefined;
    };
    return {
      comment,
      defines: pick(obj.defines, t.relatedDefines?.map(d => d.name)),
      elements: pick(obj.elements, t.elements?.map(e => e.name)),
    };
  };
}

/** 流程图生成结果（静态生成，永不抛错——一切异常收敛到 L3 顺序链兜底图） */
export interface FlowchartGenResult {
  warnings: string[];
  degraded: 'none' | 'subtree' | 'block';
  /** 断言网检出缺陷（CFG 生成器 bug 信号，应进 failures 让人工知晓；图已按 L3 兜底写出） */
  defect?: string;
}

/** 为单个函数生成流程图：tree-sitter CFG 静态构建（零 LLM，结构确定性）。
 *  断言网 flowchartProblems 自检；失败/异常一律降 L3 顺序链兜底——gen 对任意函数必出图 */
async function genFlowchart(
  fn: FunctionUnit,
  readSource: ((relPath: string) => string | null) | undefined,
): Promise<FlowchartGenResult> {
  let diagram: string;
  let warnings: string[] = [];
  let degraded: FlowchartGenResult['degraded'] = 'none';
  let defect: string | undefined;
  try {
    if (!readSource) throw new Error('无源码读取通道（readSource 未配置）');
    const source = readSource(fn.file);
    if (source == null) throw new Error(`源码文件读取失败: ${fn.file}`);
    const r = await buildStaticFlowchart(fn, source);
    diagram = r.mermaid;
    warnings = r.warnings;
    degraded = r.degraded;
    // 断言网只查实际画出框的宏：空区域（#if 只包花括号等片段）被构造性抑制，
    // 不应触发「缺少条件编译虚线框」误报把整个函数打进 L3（抑制本身已记 warnings）
    const fnView: FunctionUnit = r.framedMacros.length === (fn.innerCondFlags ?? []).length
      ? fn
      : { ...fn, innerCondFlags: (fn.innerCondFlags ?? []).filter(m => r.framedMacros.includes(m)) };
    const problems = flowchartProblems(fnView, diagram);
    if (problems.length > 0) throw new Error(`断言网检出 ${problems.length} 个问题: ${problems.join('；')}`);
  } catch (err) {
    defect = `CFG生成器缺陷（已降 L3 兜底）: ${(err as Error).message}`;
    degraded = 'block';
    diagram = buildFallbackFlowchart(fn);
    // 兜底图也过一遍断言网：L3 构造上应全绿，出问题说明是更深的生成器 bug
    const fbProblems = flowchartProblems(fn, diagram);
    if (fbProblems.length > 0) defect += `；L3 兜底图仍有 ${fbProblems.length} 个问题: ${fbProblems.join('；')}`;
  }
  fn.generated = fn.generated ?? {
    detailedDescription: '', llmModel: 'static-cfg', generatedAt: new Date().toISOString(),
  };
  fn.generated.flowchart = diagram;
  fn.generated.flowchartFormat = 'mermaid';
  stampContentHash(fn.generated);   // 生成时刻指纹：描述（enrichFunction 先赋）+流程图齐后打
  return { warnings, degraded, defect };
}

/** 为单个函数生成增强描述（LLM）+ 流程图（静态） */
async function enrichFunction(
  model: ModuleModel,
  fn: FunctionUnit,
  provider: LLMProvider,
  abbr?: [string, string][],
  readSource?: (relPath: string) => string | null,
): Promise<FlowchartGenResult> {
  const { system, user } = buildFunctionDescriptionPrompt(model, fn);
  const text = await generateWithRetry(provider, system, withGlossary(user, abbr), (o) => {
    const cleaned = o.trim();
    if (cleaned.length < 20) throw new Error('描述过短（<20字符）');
    return cleaned;
  });
  fn.generated = {
    detailedDescription: text,
    llmModel: provider.name,
    generatedAt: new Date().toISOString(),
  };

  return genFlowchart(fn, readSource);
}

/** 生成动态设计（5.3 状态机 + 序列图，均确定性静态；skip 用于 --resume 时只补缺的一半） */
async function generateDynamicDesign(
  model: ModuleModel,
  provider: LLMProvider,
  skip?: { stateMachine?: boolean; sequences?: boolean },
  readSource?: (relPath: string) => string | null,
  log: (msg: string) => void = () => {},
): Promise<DynamicDesign> {
  const result: DynamicDesign = { stateMachine: null, sequences: [] };

  // ---- 状态机：确定性静态生成（CFG 抽象解释提取迁移；降级阶梯 L0-L3 必出图） ----
  // 结构零 LLM；迁移标签随后交 LLM 润色为中文短句（09-20 定调），失败保持原文
  if (!skip?.stateMachine) {
    const smOut = await buildStaticStateMachine(model, readSource);
    if (smOut) {
      for (const w of smOut.warnings) log(`  ⚠ 状态机: ${w}`);
      if (smOut.degraded !== 'none') log(`  ⚠ 状态机: 降级级别 ${smOut.degraded}`);
      for (const sm of smOut.sms) {
        const warn = await polishSmLabels(sm, model.module, provider, smOut.edgeCtx.get(sm), smOut.stateCtx.get(sm));
        if (warn) log(`  ⚠ 状态机标签润色(${sm.name}): ${warn}`);
      }
      result.stateMachine = smOut.sms[0] ?? null;   // 兼容位：旧读取口径只看第一张
      if (smOut.sms.length > 1) result.stateMachines = smOut.sms;
    }
  }

  // ---- 序列图：确定性静态生成（CFG 遍历发消息+组合片段；09-21 定调不依赖 LLM） ----
  // 初始化入口 + 周期入口（命名约定 _Startup|_Init / _MainFunction|_Mainfunction，大小写兼容）
  // scenario 沿用英文场景名（与 v6 基准命名一致）；label 为描述段中文场景名
  const scenarios: { pattern: RegExp; scenario: string; label: string }[] = [
    { pattern: /_(Startup|Init)$/i, scenario: 'Initialization', label: '初始化' },
    { pattern: /_MainFunction$/i, scenario: 'Runtime', label: '周期运行' },
  ];
  for (const { pattern, scenario, label } of skip?.sequences ? [] : scenarios) {
    const fn = model.providedFunctions.find(f => pattern.test(f.name));
    if (!fn) continue;
    const out = await buildStaticSequence(model, fn, readSource, label);
    for (const w of out.warnings) log(`  ⚠ 序列图(${scenario}): ${w}`);
    if (out.degraded !== 'none') log(`  ⚠ 序列图(${scenario}): 降级级别 ${out.degraded}`);
    // 多核模块按角色分图：主核 Core0 / 从核 satellite 各成一张工作项
    for (const part of out.parts) {
      const name = part.role ? `${scenario}（${part.role}）` : scenario;
      result.sequences.push({
        name,
        diagram: part.diagram,
        diagramFormat: 'mermaid',
        description: part.description,
        polarion: {
          isWorkItem: true, chapter: '5.3.2', workItemKind: 'sequence',
          title: part.role ? `${model.module} ${scenario} 序列图（${part.role}）` : `${model.module} ${scenario} 序列图`,
          workItemId: null,
        },
      } satisfies SequenceDesign);
    }
  }

  return result;
}

export interface GenerateOptions {
  /** 只生成指定条目（函数名或 'dynamic'/'configs'/'callouts'/'flowcharts'/'types'/'externals'/'description'），空 = 全部 */
  only?: string[];
  /** 断点续跑：跳过已有 generated 内容的条目（配合 CLI --resume） */
  skipExisting?: boolean;
  /** 进度回调 */
  onProgress?: (msg: string) => void;
  /** 失败收集：单条目失败不中断整批，失败原因 push 进该数组由调用方汇总 */
  failures?: string[];
  /** 外部缩写定义（lld.config.json 的 abbreviationsDoc/abbreviations 解析结果）——按 prompt 内实际出现
   *  过滤后注入文本类生成（描述/配置说明/类型注释/外部接口说明/5.1），术语口径与外部定义一致 */
  abbreviations?: [string, string][];
  /** 报告骨架内容（document 节）物化用的缩写表全量解析结果（entries+definitions+replace+source）；
   *  缺省 = 纯内置词典合并模式。仅在 document 生成点消费 */
  abbreviationTable?: AbbrTableInput;
  /** 源文件读取通道（core 不碰 fs，由 CLI 注入）：流程图静态生成按 fn.file 重解析用。
   *  返回 null = 读不到（该函数降 L3 兜底图） */
  readSource?: (relPath: string) => string | null;
}

/** 生成入口：就地增强 model（函数 generated 字段 + dynamicDesign）。
 *  provider 可为 null——仅当只跑 --only flowcharts（纯静态生成）时允许 */
export async function generateDesign(
  model: ModuleModel,
  provider: LLMProvider | null,
  opts?: GenerateOptions,
): Promise<ModuleModel> {
  const log = opts?.onProgress ?? (() => {});
  const only = opts?.only;
  const skipExisting = opts?.skipExisting ?? false;

  // v1→v2 读取侧迁移：存量 json 的 Callout 从 calledExternalFunctions 挪入 calloutFunctions（幂等）
  normalizeModel(model);

  // 结构版本回填：存量 json（v1 前形态）经任何 gen 通道写回时补 schemaVersion
  model.schemaVersion ??= SCHEMA_VERSION;
  // Polarion 属性物化（wiType/verifyMethod）：任何 gen 通道（含 --only document/flowcharts 早退路径）
  // 都先幂等重刷五类节点与章节级条目；gen 期新创建的状态机/序列图由末尾的第二次调用补齐
  materializePolarionAttributes(model);

  // 报告骨架内容物化（零 LLM 确定性，幂等重算）。--only document（可叠加 flowcharts）时
  // 免 provider 直接物化；全量 gen 在末尾统一物化——3.1 出现过滤扫描 generated 文本，
  // 须在描述类生成完成后执行，否则漏收描述里的新缩写
  const docStage = (): void => {
    // 合并而非整节替换：buildDocumentContent 不产出的字段（如 gen --only images 物化的
    // includeGraphPng）须保留——0929 整节替换曾把该 PNG 静默冲掉
    model.document = { ...model.document, ...buildDocumentContent(model, opts?.abbreviationTable) };
    log('物化报告骨架内容（document 节：1/2/3/7/8 章正文与各章引导句）');
  };
  if (only?.includes('document') && !only.some(o => o !== 'document' && o !== 'flowcharts')) {
    docStage();
    if (!only.includes('flowcharts')) return model;
  }

  // --only flowcharts：只重刷各函数的流程图，保留已生成的描述等其余内容；纯静态生成，无需 LLM
  if (only?.includes('flowcharts')) {
    const fnFilter = only.filter(o => o !== 'flowcharts');
    for (const fn of [...model.providedFunctions, ...model.internalFunctions]) {
      if (fnFilter.length > 0 && !fnFilter.includes(fn.name)) continue;
      log(`重新生成流程图: ${fn.name}`);
      try {
        const r = await genFlowchart(fn, opts?.readSource);
        for (const w of r.warnings) log(`  ⚠ ${fn.name}: ${w}`);
        if (r.degraded !== 'none') log(`  ⚠ ${fn.name}: 降级级别 ${r.degraded}`);
        if (r.defect) opts?.failures?.push(`${fn.name}: ${r.defect}`);
      } catch (err) {
        log(`  ⚠ 失败（已跳过，可 --resume 重试）: ${fn.name} — ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`${fn.name}: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
    return model;
  }

  // 其余生成项均需 LLM
  if (!provider) throw new Error('生成描述/动态设计/配置说明等内容需要 LLM Provider（仅 --only flowcharts 可免 LLM）');

  const allFunctions = [...model.providedFunctions, ...model.internalFunctions];
  const targets = only
    ? allFunctions.filter(f => only.includes(f.name))
    : allFunctions;

  for (const fn of targets) {
    if (skipExisting && fn.generated?.detailedDescription && fn.generated.flowchart) {
      log(`跳过（已有生成内容）: ${fn.name}`);
      continue;
    }
    log(`生成描述: ${fn.name}`);
    try {
      const r = await enrichFunction(model, fn, provider, opts?.abbreviations, opts?.readSource);
      for (const w of r.warnings) log(`  ⚠ ${fn.name}: ${w}`);
      if (r.degraded !== 'none') log(`  ⚠ ${fn.name}: 流程图降级级别 ${r.degraded}`);
      if (r.defect) opts?.failures?.push(`${fn.name}: ${r.defect}`);
    } catch (err) {
      log(`  ⚠ 失败（已跳过，可 --resume 重试）: ${fn.name} — ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      opts?.failures?.push(`${fn.name}: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
    }
  }

  if ((!only || only.includes('dynamic'))) {
    // 空壳 dynamicDesign（stateMachine=null 且 sequences=[]）不算已有——否则失败后 --resume 永远跳过；
    // 粒度细分：状态机与序列图各自判断，--resume 只补缺的一半
    //（如手工清掉 sequences 重出时保留已验收的状态机，避免 TLF 宏族状态机被重抽）
    const existing = model.dynamicDesign ?? undefined;
    const keepSM = !!(skipExisting && existing?.stateMachine);
    const keepSeq = !!(skipExisting && existing && existing.sequences.length > 0);
    if (keepSM && keepSeq) {
      log('跳过（已有动态设计）');
    } else {
      log('生成动态设计（状态机/序列图）');
      try {
        const fresh = await generateDynamicDesign(model, provider, { stateMachine: keepSM, sequences: keepSeq }, opts?.readSource, log);
        model.dynamicDesign = {
          stateMachine: keepSM ? existing!.stateMachine : fresh.stateMachine,
          stateMachines: keepSM ? existing!.stateMachines : fresh.stateMachines,
          sequences: keepSeq ? existing!.sequences : fresh.sequences,
        };
      } catch (err) {
        log(`  ⚠ 动态设计失败（已跳过，可 --resume 重试）: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`dynamic: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
  }

  if (!only || only.includes('configs')) {
    for (const macro of model.configMacros) {
      if (macro.kind === 'alias') continue;   // 别名宏非配置项，不生成取值说明
      if (skipExisting && macro.generated?.valueEffect) {
        log(`跳过（已有配置说明）: ${macro.name}`);
        continue;
      }
      log(`生成配置说明: ${macro.name}`);
      const { system, user } = buildConfigValueEffectPrompt(model, macro);
      try {
        const text = await generateWithRetry(provider, system, withGlossary(user, opts?.abbreviations), (o) => {
          const cleaned = o.trim();
          if (cleaned.length < 10) throw new Error('说明过短（<10字符）');
          return cleaned;
        });
        macro.generated = {
          valueEffect: text,
          llmModel: provider.name,
          generatedAt: new Date().toISOString(),
        };
        stampContentHash(macro.generated);
      } catch (err) {
        log(`  ⚠ 失败（已跳过，可 --resume 重试）: ${macro.name} — ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`${macro.name}: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
  }

  if (!only || only.includes('callouts')) {
    for (const ext of model.calloutFunctions) {
      if (skipExisting && ext.generated?.detailedDescription) {
        log(`跳过（已有 Callout 描述）: ${ext.name}`);
        continue;
      }
      log(`生成 Callout 描述: ${ext.name}`);
      const { system, user } = buildCalloutDescriptionPrompt(model, ext);
      try {
        const text = await generateWithRetry(provider, system, withGlossary(user, opts?.abbreviations), (o) => {
          const cleaned = o.trim();
          if (cleaned.length < 10) throw new Error('描述过短（<10字符）');
          return cleaned;
        });
        ext.generated = {
          detailedDescription: text,
          llmModel: provider.name,
          generatedAt: new Date().toISOString(),
        };
        stampContentHash(ext.generated);
      } catch (err) {
        log(`  ⚠ 失败（已跳过，可 --resume 重试）: ${ext.name} — ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`${ext.name}: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
  }

  if (!only || only.includes('types')) {
    for (const t of model.types) {
      if (skipExisting && t.generated?.comment) {
        log(`跳过（已有类型描述）: ${t.name}`);
        continue;
      }
      log(`生成类型描述: ${t.name}`);
      const { system, user } = buildTypeDescriptionPrompt(model, t);
      try {
        const parsed = await generateWithRetry(provider, system, withGlossary(user, opts?.abbreviations), validateTypeDescription(t));
        t.generated = {
          ...parsed,
          llmModel: provider.name,
          generatedAt: new Date().toISOString(),
        };
        stampContentHash(t.generated);
      } catch (err) {
        log(`  ⚠ 失败（已跳过，可 --resume 重试）: ${t.name} — ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`${t.name}: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
  }

  if (!only || only.includes('externals')) {
    for (const ext of model.calledExternalFunctions) {
      if (skipExisting && ext.generated?.detailedDescription) {
        log(`跳过（已有外部接口说明）: ${ext.name}`);
        continue;
      }
      log(`生成外部接口说明: ${ext.name}`);
      const { system, user } = buildExternalDescriptionPrompt(model, ext);
      try {
        const text = await generateWithRetry(provider, system, withGlossary(user, opts?.abbreviations), (o) => {
          const cleaned = o.trim();
          if (cleaned.length < 10) throw new Error('说明过短（<10字符）');
          return cleaned;
        });
        ext.generated = {
          detailedDescription: text,
          llmModel: provider.name,
          generatedAt: new Date().toISOString(),
        };
        stampContentHash(ext.generated);
      } catch (err) {
        log(`  ⚠ 失败（已跳过，可 --resume 重试）: ${ext.name} — ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`${ext.name}: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
  }

  if (!only || only.includes('description')) {
    if (skipExisting && model.functionalDescription) {
      log('跳过（已有模块功能描述）');
    } else {
      log('生成模块功能描述（5.1）');
      const { system, user } = buildModuleDescriptionPrompt(model);
      try {
        const text = await generateWithRetry(provider, system, withGlossary(user, opts?.abbreviations), (o) => {
          const cleaned = o.trim();
          if (cleaned.length < 20) throw new Error('描述过短（<20字符）');
          return cleaned;
        });
        model.functionalDescription = text;
      } catch (err) {
        log(`  ⚠ 模块功能描述失败（已跳过，可 --resume 重试）: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
        opts?.failures?.push(`description: ${(err as Error).message.replace(/\n/g, '\n      ')}`);
      }
    }
  }

  // 内容指纹回填（2026-10-16 人工修订检出）：存量条目 generated 无 contentHash 的补基线指纹。
  // 注意：若条目此前已被手改，此处以当前内容为基线（无法区分）——指纹自首跑新版本工具起生效
  if (!only || only.some(o => !['document', 'flowcharts', 'images'].includes(o))) {
    let stamped = 0;
    const gens = [
      ...[...model.providedFunctions, ...model.internalFunctions].map(f => f.generated),
      ...model.types.map(t => t.generated),
      ...model.calledExternalFunctions.map(e => e.generated),
      ...model.calloutFunctions.map(e => e.generated),
      ...model.configMacros.map(c => c.generated),
    ];
    for (const g of gens) {
      if (g && !g.contentHash) { stampContentHash(g); stamped++; }
    }
    if (stamped > 0) log(`内容指纹回填: ${stamped} 条存量 generated 补基线 contentHash`);
  }

  // 末尾统一物化报告骨架内容（全量 gen 或 --only 含 document 且混杂 LLM 阶段时在此落地）
  if (!only || only.includes('document')) docStage();

  // Polarion 属性第二次物化：gen 期才创建的状态机/序列图 marker 在此补齐（幂等覆盖写）
  materializePolarionAttributes(model);

  return model;
}
